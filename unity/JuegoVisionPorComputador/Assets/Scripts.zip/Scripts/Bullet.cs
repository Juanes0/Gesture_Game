using UnityEngine;

public class Bullet : MonoBehaviour
{
    [Header("Configuración Bala")]
    public float speed = 18f;        // Velocidad alta (importante)
    public float lifetime = 2.5f;

    private Rigidbody2D rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Start()
    {
        if (rb != null)
        {
            // Aplicamos velocidad directamente aquí también (por seguridad)
            rb.linearVelocity = transform.right * speed;
        }

        Destroy(gameObject, lifetime);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player")) return;
        Destroy(gameObject);   // Se destruye al tocar cualquier cosa
    }
}